# piano_py
My Python project is a small piano controlled by keys.
** Attention!** Before starting the project, read the file important.txt .
